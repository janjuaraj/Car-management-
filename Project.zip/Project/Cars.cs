﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace POSapp
{
    internal class Cars
    {
        public int CarId;
        public string ModelName;
        public string EngineNumber;
        public int YearManufactured;
        public string BatteryCapacity;
        public decimal Price;
        public string Status;
        public int Stock;
        public string Color;
        public byte[] CarImage;
        public int SupplierId;

        public Cars() { }

        public Cars(int carid, string modelName, string engineNumber, int yearManufactured, string batteryCapacity, decimal price, string status, int stock, string color, byte[] carImage, int supplierId)
        {
            CarId = carid;
            ModelName = modelName;
            EngineNumber = engineNumber;
            YearManufactured = yearManufactured;
            BatteryCapacity = batteryCapacity;
            Price = price;
            Status = status;
            Stock = stock;
            Color = color;
            CarImage = carImage;
            SupplierId = supplierId;
        }
        public void SetCarId(int carId)
        {
            CarId = carId;
        }

        public int GetCarId()
        {
            return CarId;
        }

        public void SetModelName(string modelName)
        {
            ModelName = modelName;
        }

        public string GetModelName()
        {
            return ModelName;
        }

        public void SetEngineNumber(string engineNumber)
        {
            EngineNumber = engineNumber;
        }

        public string GetEngineNumber()
        {
            return EngineNumber;
        }

        public void SetYearManufactured(int yearManufactured)
        {
            YearManufactured = yearManufactured;
        }

        public int GetYearManufactured()
        {
            return YearManufactured;
        }

        public void SetBatteryCapacity(string batteryCapacity)
        {
            BatteryCapacity = batteryCapacity;
        }

        public string GetBatteryCapacity()
        {
            return BatteryCapacity;
        }

        public void SetPrice(decimal price)
        {
            Price = price;
        }

        public decimal GetPrice()
        {
            return Price;
        }

        public void SetStatus(string status)
        {
            Status = status;
        }

        public string GetStatus()
        {
            return Status;
        }

        public void SetStock(int stock)
        {
            Stock = stock;
        }

        public int GetStock()
        {
            return Stock;
        }

        public void SetColor(string color)
        {
            Color = color;
        }

        public string GetColor()
        {
            return Color;
        }

        public void SetCarImage(byte[] carImage)
        {
            CarImage = carImage;
        }

        public byte[] GetCarImage()
        {
            return CarImage;
        }

        public void SetSupplierId(int supplierId)
        {
            SupplierId = supplierId;
        }

        public int GetSupplierId()
        {
            return SupplierId;
        }
    }
}
