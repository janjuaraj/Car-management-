﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POSapp
{
    public partial class CarSales_Form:Form
    {
        public CarSales_Form()
        {
            InitializeComponent();
        }

        private void CarSales_Form_Load(object sender, EventArgs e)
        {
            LoadSales();
        }
        
        private void LoadSales()
        {
            gridSales.Rows.Clear();
            gridSales.Columns.Clear();

            gridSales.Columns.Add("SALEID", "Sale ID");
            gridSales.Columns.Add("USERID", "User ID");
            gridSales.Columns.Add("CARID", "Car ID");
            gridSales.Columns.Add("MODELNAME", "Model Name");
            gridSales.Columns.Add("COLOR", "Color");
            gridSales.Columns.Add("YEARMANUFACTURED", "Year Manufactured");
            gridSales.Columns.Add("PRICE", "Price");
            gridSales.Columns.Add("DATESOLD", "Date Sold");

            var salesList = Database.GetCarSales();
            for (int i = 0; i < salesList.Count; i++)
            {
                gridSales.Rows.Add(
                    salesList[i].SaleId,
                    salesList[i].UserId,
                    salesList[i].CarId,
                    salesList[i].ModelName,
                    salesList[i].Color,
                    salesList[i].YearManufactured,
                    salesList[i].Price,
                    salesList[i].DateSold.ToString("yyyy-MM-dd")
                );
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Admin_Dashboard dashboard = new Admin_Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtCarId.Text == null)
            {
                LoadSales();
            }
            else
            {
                Car_Sales sales = new Car_Sales();
                int carid = Convert.ToInt32(txtCarId.Text);
                DataTable data = Database.SearchCarSalesByCarId(carid.ToString());
                gridSales.Rows.Clear();
                gridSales.Columns.Clear();
                gridSales.DataSource = data;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtCarId.Text == null)
            {
                LoadSales();
            }
            else
            {
                Car_Sales sales = new Car_Sales();
                int UserId = Convert.ToInt32(txtUserId.Text);
                DataTable data = Database.SearchCarSalesByUserId(UserId.ToString());
                gridSales.Rows.Clear();
                gridSales.Columns.Clear();
                gridSales.DataSource = data;
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtDateSold.Text == null)
            {
                LoadSales();
            }
            else
            {
                Car_Sales sales = new Car_Sales();
                sales.DateSold = Convert.ToDateTime(txtDateSold.Text);
                DataTable data = Database.SearchCarSalesByDateSold(sales.DateSold.ToString("yyyy-MM-dd"));
                gridSales.Rows.Clear();
                gridSales.Columns.Clear();
                gridSales.DataSource = data;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Admin_Dashboard d = new Admin_Dashboard();
            d.Show();
            this.Hide();
        }

        private void txtCarId_TextChanged(object sender, EventArgs e)
        {

        }


        private void txtDateSold_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUserId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
