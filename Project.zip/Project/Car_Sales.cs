﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSapp
{
    internal class Car_Sales
    {
        public int SaleId;
        public DateTime DateSold;
        public Cars Car = new Cars();
        public Users User = new Users();
        public Car_Sales(int saleId, int userId, int carId,DateTime dateSold)
        {
            SaleId = saleId;
            DateSold = dateSold;
            Car.SetCarId( carId);
            Car.SetCarId(userId);
        }
        public Car_Sales() { }
        public void SetSaleId(int saleId)
        {
            SaleId = saleId;
        }
        public void SetDateSold(DateTime dateSold)
        {
            DateSold = dateSold;
        }
        public void SetCarId(int carId)
        {
            Car.SetCarId(carId);
        }
        public void SetUserId(int userId)
        {
            Car.SetCarId(userId);
        }
    }
}
