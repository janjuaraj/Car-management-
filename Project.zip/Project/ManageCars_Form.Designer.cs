﻿namespace POSapp
{
    partial class ManageCars_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtEngineNumber = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBattery = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSupplierId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnLoadImg = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.carsGrid = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCarId = new System.Windows.Forms.TextBox();
            this.pictureBoxCar = new System.Windows.Forms.PictureBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtcolor = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel82 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.panel84 = new System.Windows.Forms.Panel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.carsGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCar)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel70.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel74.SuspendLayout();
            this.panel75.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel81.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(923, 54);
            this.panel1.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(379, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 28);
            this.label3.TabIndex = 4;
            this.label3.Text = "Manage Cars";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 17);
            this.label1.TabIndex = 30;
            this.label1.Text = "Model Name";
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(187, 106);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(162, 20);
            this.txtModel.TabIndex = 31;
            // 
            // txtEngineNumber
            // 
            this.txtEngineNumber.Location = new System.Drawing.Point(187, 136);
            this.txtEngineNumber.Name = "txtEngineNumber";
            this.txtEngineNumber.Size = new System.Drawing.Size(162, 20);
            this.txtEngineNumber.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(47, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 17);
            this.label7.TabIndex = 40;
            this.label7.Text = "Engine Number";
            // 
            // txtBattery
            // 
            this.txtBattery.Location = new System.Drawing.Point(187, 221);
            this.txtBattery.Name = "txtBattery";
            this.txtBattery.Size = new System.Drawing.Size(162, 20);
            this.txtBattery.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(47, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 17);
            this.label2.TabIndex = 42;
            this.label2.Text = "Battery Capacity";
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(187, 191);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(162, 20);
            this.txtYear.TabIndex = 45;
            this.txtYear.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 17);
            this.label4.TabIndex = 44;
            this.label4.Text = "Year";
            // 
            // txtSupplierId
            // 
            this.txtSupplierId.Location = new System.Drawing.Point(187, 315);
            this.txtSupplierId.Name = "txtSupplierId";
            this.txtSupplierId.Size = new System.Drawing.Size(162, 20);
            this.txtSupplierId.TabIndex = 51;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(47, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 17);
            this.label5.TabIndex = 50;
            this.label5.Text = "Supplier ID";
            // 
            // txtStock
            // 
            this.txtStock.Location = new System.Drawing.Point(187, 345);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(162, 20);
            this.txtStock.TabIndex = 49;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 48;
            this.label6.Text = "Stock";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(187, 252);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(162, 20);
            this.txtPrice.TabIndex = 47;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(47, 253);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 17);
            this.label8.TabIndex = 46;
            this.label8.Text = "Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(47, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 17);
            this.label9.TabIndex = 52;
            this.label9.Text = "Status";
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Available",
            "Sold",
            "Rented"});
            this.cmbStatus.Location = new System.Drawing.Point(187, 283);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(162, 21);
            this.cmbStatus.TabIndex = 53;
            this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(532, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 54;
            this.label10.Text = "Car Image";
            // 
            // btnLoadImg
            // 
            this.btnLoadImg.Location = new System.Drawing.Point(643, 282);
            this.btnLoadImg.Name = "btnLoadImg";
            this.btnLoadImg.Size = new System.Drawing.Size(100, 23);
            this.btnLoadImg.TabIndex = 55;
            this.btnLoadImg.Text = "Upload Image";
            this.btnLoadImg.UseVisualStyleBackColor = true;
            this.btnLoadImg.Click += new System.EventHandler(this.btnLoadImg_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(270, 387);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(107, 32);
            this.btn_delete.TabIndex = 58;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(155, 387);
            this.btn_update.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(107, 32);
            this.btn_update.TabIndex = 57;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(40, 387);
            this.btn_add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(107, 32);
            this.btn_add.TabIndex = 56;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(385, 387);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 32);
            this.button2.TabIndex = 59;
            this.button2.Text = "Clear Fields";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(550, 394);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(162, 20);
            this.txtSearch.TabIndex = 61;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(547, 368);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 17);
            this.label11.TabIndex = 60;
            this.label11.Text = "Search by Model";
            // 
            // carsGrid
            // 
            this.carsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.carsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.carsGrid.Location = new System.Drawing.Point(12, 436);
            this.carsGrid.Name = "carsGrid";
            this.carsGrid.ReadOnly = true;
            this.carsGrid.RowHeadersWidth = 45;
            this.carsGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.carsGrid.Size = new System.Drawing.Size(875, 226);
            this.carsGrid.TabIndex = 62;
            this.carsGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.carsGrid_CellContentClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(49, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 17);
            this.label12.TabIndex = 63;
            this.label12.Text = "Car ID";
            // 
            // txtCarId
            // 
            this.txtCarId.Location = new System.Drawing.Point(187, 74);
            this.txtCarId.Name = "txtCarId";
            this.txtCarId.Size = new System.Drawing.Size(162, 20);
            this.txtCarId.TabIndex = 64;
            // 
            // pictureBoxCar
            // 
            this.pictureBoxCar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxCar.Location = new System.Drawing.Point(535, 114);
            this.pictureBoxCar.Name = "pictureBoxCar";
            this.pictureBoxCar.Size = new System.Drawing.Size(314, 157);
            this.pictureBoxCar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCar.TabIndex = 65;
            this.pictureBoxCar.TabStop = false;
            this.pictureBoxCar.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(739, 387);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 30);
            this.btnSearch.TabIndex = 67;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtcolor
            // 
            this.txtcolor.Location = new System.Drawing.Point(187, 165);
            this.txtcolor.Name = "txtcolor";
            this.txtcolor.Size = new System.Drawing.Size(162, 20);
            this.txtcolor.TabIndex = 69;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(47, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 17);
            this.label13.TabIndex = 68;
            this.label13.Text = "Color";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 679);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(191, 31);
            this.button1.TabIndex = 108;
            this.button1.Text = "< Back to Admin Dashboard";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(186, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(163, 3);
            this.panel3.TabIndex = 128;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(-1, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(163, 3);
            this.panel2.TabIndex = 128;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(-1, -1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(163, 3);
            this.panel4.TabIndex = 128;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(-1, -1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(163, 3);
            this.panel5.TabIndex = 128;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(-1, -1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(163, 3);
            this.panel6.TabIndex = 128;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(-1, -1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(163, 3);
            this.panel7.TabIndex = 128;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(-1, -1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(163, 3);
            this.panel8.TabIndex = 128;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Location = new System.Drawing.Point(-1, -1);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(163, 3);
            this.panel9.TabIndex = 128;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(-1, -1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(163, 3);
            this.panel10.TabIndex = 128;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Location = new System.Drawing.Point(-1, -1);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(163, 3);
            this.panel11.TabIndex = 128;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Location = new System.Drawing.Point(186, 123);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(163, 3);
            this.panel12.TabIndex = 128;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Location = new System.Drawing.Point(186, 91);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(163, 3);
            this.panel13.TabIndex = 128;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Location = new System.Drawing.Point(186, 153);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(163, 3);
            this.panel14.TabIndex = 129;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Location = new System.Drawing.Point(-1, -1);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(163, 3);
            this.panel15.TabIndex = 128;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(-1, -1);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(163, 3);
            this.panel16.TabIndex = 128;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Location = new System.Drawing.Point(-1, -1);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(163, 3);
            this.panel17.TabIndex = 128;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Location = new System.Drawing.Point(-1, -1);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(163, 3);
            this.panel18.TabIndex = 128;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Location = new System.Drawing.Point(-1, -1);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(163, 3);
            this.panel19.TabIndex = 128;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Location = new System.Drawing.Point(-1, -1);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(163, 3);
            this.panel20.TabIndex = 128;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Location = new System.Drawing.Point(-1, -1);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(163, 3);
            this.panel21.TabIndex = 128;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Location = new System.Drawing.Point(-1, -1);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(163, 3);
            this.panel22.TabIndex = 128;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Location = new System.Drawing.Point(-1, -1);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(163, 3);
            this.panel23.TabIndex = 128;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.panel25);
            this.panel24.Location = new System.Drawing.Point(187, 210);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(163, 3);
            this.panel24.TabIndex = 130;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Location = new System.Drawing.Point(-1, -1);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(163, 3);
            this.panel25.TabIndex = 128;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Location = new System.Drawing.Point(-1, -1);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(163, 3);
            this.panel26.TabIndex = 128;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.panel28);
            this.panel27.Location = new System.Drawing.Point(-1, -1);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(163, 3);
            this.panel27.TabIndex = 128;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Location = new System.Drawing.Point(-1, -1);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(163, 3);
            this.panel28.TabIndex = 128;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Location = new System.Drawing.Point(-1, -1);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(163, 3);
            this.panel29.TabIndex = 128;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Location = new System.Drawing.Point(-1, -1);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(163, 3);
            this.panel30.TabIndex = 128;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Location = new System.Drawing.Point(-1, -1);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(163, 3);
            this.panel31.TabIndex = 128;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.panel33);
            this.panel32.Location = new System.Drawing.Point(-1, -1);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(163, 3);
            this.panel32.TabIndex = 128;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Location = new System.Drawing.Point(-1, -1);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(163, 3);
            this.panel33.TabIndex = 128;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.panel35);
            this.panel34.Location = new System.Drawing.Point(187, 238);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(163, 3);
            this.panel34.TabIndex = 129;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Location = new System.Drawing.Point(-1, -1);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(163, 3);
            this.panel35.TabIndex = 128;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Location = new System.Drawing.Point(-1, -1);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(163, 3);
            this.panel36.TabIndex = 128;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.Controls.Add(this.panel38);
            this.panel37.Location = new System.Drawing.Point(-1, -1);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(163, 3);
            this.panel37.TabIndex = 128;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Location = new System.Drawing.Point(-1, -1);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(163, 3);
            this.panel38.TabIndex = 128;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.Controls.Add(this.panel40);
            this.panel39.Location = new System.Drawing.Point(-1, -1);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(163, 3);
            this.panel39.TabIndex = 128;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.panel41);
            this.panel40.Location = new System.Drawing.Point(-1, -1);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(163, 3);
            this.panel40.TabIndex = 128;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Location = new System.Drawing.Point(-1, -1);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(163, 3);
            this.panel41.TabIndex = 128;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.panel43);
            this.panel42.Location = new System.Drawing.Point(-1, -1);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(163, 3);
            this.panel42.TabIndex = 128;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.Location = new System.Drawing.Point(-1, -1);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(163, 3);
            this.panel43.TabIndex = 128;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.panel45);
            this.panel44.Location = new System.Drawing.Point(187, 269);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(163, 3);
            this.panel44.TabIndex = 130;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel45.Controls.Add(this.panel46);
            this.panel45.Location = new System.Drawing.Point(-1, -1);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(163, 3);
            this.panel45.TabIndex = 128;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel46.Controls.Add(this.panel47);
            this.panel46.Location = new System.Drawing.Point(-1, -1);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(163, 3);
            this.panel46.TabIndex = 128;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel47.Controls.Add(this.panel48);
            this.panel47.Location = new System.Drawing.Point(-1, -1);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(163, 3);
            this.panel47.TabIndex = 128;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel48.Controls.Add(this.panel49);
            this.panel48.Location = new System.Drawing.Point(-1, -1);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(163, 3);
            this.panel48.TabIndex = 128;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Location = new System.Drawing.Point(-1, -1);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(163, 3);
            this.panel49.TabIndex = 128;
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel50.Controls.Add(this.panel51);
            this.panel50.Location = new System.Drawing.Point(-1, -1);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(163, 3);
            this.panel50.TabIndex = 128;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel51.Controls.Add(this.panel52);
            this.panel51.Location = new System.Drawing.Point(-1, -1);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(163, 3);
            this.panel51.TabIndex = 128;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel52.Controls.Add(this.panel53);
            this.panel52.Location = new System.Drawing.Point(-1, -1);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(163, 3);
            this.panel52.TabIndex = 128;
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel53.Location = new System.Drawing.Point(-1, -1);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(163, 3);
            this.panel53.TabIndex = 128;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel54.Controls.Add(this.panel55);
            this.panel54.Location = new System.Drawing.Point(187, 301);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(163, 3);
            this.panel54.TabIndex = 130;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Location = new System.Drawing.Point(-1, -1);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(163, 3);
            this.panel55.TabIndex = 128;
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel56.Controls.Add(this.panel57);
            this.panel56.Location = new System.Drawing.Point(-1, -1);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(163, 3);
            this.panel56.TabIndex = 128;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel57.Controls.Add(this.panel58);
            this.panel57.Location = new System.Drawing.Point(-1, -1);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(163, 3);
            this.panel57.TabIndex = 128;
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel58.Controls.Add(this.panel59);
            this.panel58.Location = new System.Drawing.Point(-1, -1);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(163, 3);
            this.panel58.TabIndex = 128;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel59.Controls.Add(this.panel60);
            this.panel59.Location = new System.Drawing.Point(-1, -1);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(163, 3);
            this.panel59.TabIndex = 128;
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel60.Controls.Add(this.panel61);
            this.panel60.Location = new System.Drawing.Point(-1, -1);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(163, 3);
            this.panel60.TabIndex = 128;
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel61.Controls.Add(this.panel62);
            this.panel61.Location = new System.Drawing.Point(-1, -1);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(163, 3);
            this.panel61.TabIndex = 128;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel62.Controls.Add(this.panel63);
            this.panel62.Location = new System.Drawing.Point(-1, -1);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(163, 3);
            this.panel62.TabIndex = 128;
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel63.Location = new System.Drawing.Point(-1, -1);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(163, 3);
            this.panel63.TabIndex = 128;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel64.Controls.Add(this.panel65);
            this.panel64.Location = new System.Drawing.Point(186, 332);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(163, 3);
            this.panel64.TabIndex = 130;
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel65.Controls.Add(this.panel66);
            this.panel65.Location = new System.Drawing.Point(-1, -1);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(163, 3);
            this.panel65.TabIndex = 128;
            // 
            // panel66
            // 
            this.panel66.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel66.Controls.Add(this.panel67);
            this.panel66.Location = new System.Drawing.Point(-1, -1);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(163, 3);
            this.panel66.TabIndex = 128;
            // 
            // panel67
            // 
            this.panel67.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel67.Controls.Add(this.panel68);
            this.panel67.Location = new System.Drawing.Point(-1, -1);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(163, 3);
            this.panel67.TabIndex = 128;
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel68.Controls.Add(this.panel69);
            this.panel68.Location = new System.Drawing.Point(-1, -1);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(163, 3);
            this.panel68.TabIndex = 128;
            // 
            // panel69
            // 
            this.panel69.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel69.Controls.Add(this.panel70);
            this.panel69.Location = new System.Drawing.Point(-1, -1);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(163, 3);
            this.panel69.TabIndex = 128;
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel70.Controls.Add(this.panel71);
            this.panel70.Location = new System.Drawing.Point(-1, -1);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(163, 3);
            this.panel70.TabIndex = 128;
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel71.Controls.Add(this.panel72);
            this.panel71.Location = new System.Drawing.Point(-1, -1);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(163, 3);
            this.panel71.TabIndex = 128;
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel72.Controls.Add(this.panel73);
            this.panel72.Location = new System.Drawing.Point(-1, -1);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(163, 3);
            this.panel72.TabIndex = 128;
            // 
            // panel73
            // 
            this.panel73.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel73.Location = new System.Drawing.Point(-1, -1);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(163, 3);
            this.panel73.TabIndex = 128;
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel74.Controls.Add(this.panel75);
            this.panel74.Location = new System.Drawing.Point(187, 362);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(163, 3);
            this.panel74.TabIndex = 130;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel75.Controls.Add(this.panel76);
            this.panel75.Location = new System.Drawing.Point(-1, -1);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(163, 3);
            this.panel75.TabIndex = 128;
            // 
            // panel76
            // 
            this.panel76.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel76.Controls.Add(this.panel77);
            this.panel76.Location = new System.Drawing.Point(-1, -1);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(163, 3);
            this.panel76.TabIndex = 128;
            // 
            // panel77
            // 
            this.panel77.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel77.Controls.Add(this.panel78);
            this.panel77.Location = new System.Drawing.Point(-1, -1);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(163, 3);
            this.panel77.TabIndex = 128;
            // 
            // panel78
            // 
            this.panel78.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel78.Controls.Add(this.panel79);
            this.panel78.Location = new System.Drawing.Point(-1, -1);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(163, 3);
            this.panel78.TabIndex = 128;
            // 
            // panel79
            // 
            this.panel79.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel79.Controls.Add(this.panel80);
            this.panel79.Location = new System.Drawing.Point(-1, -1);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(163, 3);
            this.panel79.TabIndex = 128;
            // 
            // panel80
            // 
            this.panel80.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel80.Controls.Add(this.panel81);
            this.panel80.Location = new System.Drawing.Point(-1, -1);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(163, 3);
            this.panel80.TabIndex = 128;
            // 
            // panel81
            // 
            this.panel81.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel81.Controls.Add(this.panel82);
            this.panel81.Location = new System.Drawing.Point(-1, -1);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(163, 3);
            this.panel81.TabIndex = 128;
            // 
            // panel82
            // 
            this.panel82.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel82.Controls.Add(this.panel83);
            this.panel82.Location = new System.Drawing.Point(-1, -1);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(163, 3);
            this.panel82.TabIndex = 128;
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel83.Location = new System.Drawing.Point(-1, -1);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(163, 3);
            this.panel83.TabIndex = 128;
            // 
            // panel84
            // 
            this.panel84.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel84.Controls.Add(this.panel85);
            this.panel84.Location = new System.Drawing.Point(550, 414);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(163, 3);
            this.panel84.TabIndex = 131;
            // 
            // panel85
            // 
            this.panel85.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel85.Controls.Add(this.panel86);
            this.panel85.Location = new System.Drawing.Point(-1, -1);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(163, 3);
            this.panel85.TabIndex = 128;
            // 
            // panel86
            // 
            this.panel86.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel86.Controls.Add(this.panel87);
            this.panel86.Location = new System.Drawing.Point(-1, -1);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(163, 3);
            this.panel86.TabIndex = 128;
            // 
            // panel87
            // 
            this.panel87.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel87.Controls.Add(this.panel88);
            this.panel87.Location = new System.Drawing.Point(-1, -1);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(163, 3);
            this.panel87.TabIndex = 128;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel88.Controls.Add(this.panel89);
            this.panel88.Location = new System.Drawing.Point(-1, -1);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(163, 3);
            this.panel88.TabIndex = 128;
            // 
            // panel89
            // 
            this.panel89.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel89.Controls.Add(this.panel90);
            this.panel89.Location = new System.Drawing.Point(-1, -1);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(163, 3);
            this.panel89.TabIndex = 128;
            // 
            // panel90
            // 
            this.panel90.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel90.Controls.Add(this.panel91);
            this.panel90.Location = new System.Drawing.Point(-1, -1);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(163, 3);
            this.panel90.TabIndex = 128;
            // 
            // panel91
            // 
            this.panel91.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Location = new System.Drawing.Point(-1, -1);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(163, 3);
            this.panel91.TabIndex = 128;
            // 
            // panel92
            // 
            this.panel92.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel92.Controls.Add(this.panel93);
            this.panel92.Location = new System.Drawing.Point(-1, -1);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(163, 3);
            this.panel92.TabIndex = 128;
            // 
            // panel93
            // 
            this.panel93.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel93.Location = new System.Drawing.Point(-1, -1);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(163, 3);
            this.panel93.TabIndex = 128;
            // 
            // ManageCars_Form
            // 
            this.ClientSize = new System.Drawing.Size(923, 722);
            this.Controls.Add(this.panel84);
            this.Controls.Add(this.panel74);
            this.Controls.Add(this.panel64);
            this.Controls.Add(this.panel54);
            this.Controls.Add(this.panel44);
            this.Controls.Add(this.panel34);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtcolor);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.pictureBoxCar);
            this.Controls.Add(this.txtCarId);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.carsGrid);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btnLoadImg);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtSupplierId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtStock);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBattery);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtEngineNumber);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "ManageCars_Form";
            this.Text = "ManageCars_Form";
            this.Load += new System.EventHandler(this.ManageCars_Form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.carsGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCar)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel65.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.panel76.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.panel82.ResumeLayout(false);
            this.panel84.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.panel90.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtEngineNumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBattery;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSupplierId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnLoadImg;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView carsGrid;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCarId;
        private System.Windows.Forms.PictureBox pictureBoxCar;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtcolor;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel93;
    }
}